import { GoogleGenAI } from "@google/genai";
import { Task, Meal, GroceryItem } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const generatePlan = async (
  currentTasks: Task[],
  currentMeals: Meal[],
  currentGroceries: GroceryItem[],
  userPrompt: string
) => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: userPrompt,
    config: {
      systemInstruction: `You are the Unified AI Life-Load Assistant. Your goal is to help the user manage their mental load by coordinating work tasks, meal planning, and grocery tracking.
      
      Current state:
      Tasks: ${JSON.stringify(currentTasks)}
      Meals: ${JSON.stringify(currentMeals)}
      Groceries: ${JSON.stringify(currentGroceries)}
      
      User request: ${userPrompt}
      
      Respond with helpful advice, suggestions for new tasks, meal ideas, or grocery items. 
      If you suggest changes, provide them in a structured way that the UI can interpret.
      Always be supportive and proactive.`,
    }
  });

  const response = await model;
  return response.text;
};

export const suggestMeals = async (preferences: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Suggest a 3-day meal plan based on these preferences: ${preferences}. 
    Return the response in JSON format with the following structure:
    {
      "meals": [
        { "name": "Meal Name", "day": "Monday", "type": "lunch", "ingredients": ["item 1", "item 2"] }
      ]
    }`,
    config: {
      responseMimeType: "application/json",
    }
  });
  
  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    console.error("Failed to parse meal suggestions", e);
    return { meals: [] };
  }
};

export const suggestGroceries = async (currentMeals: Meal[], currentGroceries: GroceryItem[]) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Based on the current meal plan and existing grocery list, suggest 5 additional items the user might need.
    
    Current Meals: ${JSON.stringify(currentMeals)}
    Current Groceries: ${JSON.stringify(currentGroceries)}
    
    Return the response in JSON format with the following structure:
    {
      "suggestions": [
        { "name": "Item Name", "reason": "Short reason why this is suggested" }
      ]
    }`,
    config: {
      responseMimeType: "application/json",
    }
  });
  
  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    console.error("Failed to parse grocery suggestions", e);
    return { suggestions: [] };
  }
};
