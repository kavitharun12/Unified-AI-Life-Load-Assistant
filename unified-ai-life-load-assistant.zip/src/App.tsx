import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  CheckSquare, 
  Utensils, 
  ShoppingCart, 
  MessageSquare, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle,
  Sparkles,
  ChevronRight,
  Menu,
  X,
  Calendar
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { Task, Meal, GroceryItem } from './types';
import { generatePlan, suggestGroceries } from './services/geminiService';
import Markdown from 'react-markdown';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const INITIAL_TASKS: Task[] = [
  { id: '1', title: 'Finish project proposal', priority: 'high', status: 'todo', category: 'work' },
  { id: '2', title: 'Book dentist appointment', priority: 'medium', status: 'todo', category: 'personal' },
];

const INITIAL_MEALS: Meal[] = [
  { id: '1', name: 'Quinoa Salad', day: 'Monday', type: 'lunch', ingredients: ['Quinoa', 'Cucumber', 'Feta', 'Lemon'] },
  { id: '2', name: 'Grilled Salmon', day: 'Monday', type: 'dinner', ingredients: ['Salmon', 'Asparagus', 'Sweet Potato'] },
];

const INITIAL_GROCERIES: GroceryItem[] = [
  { id: '1', name: 'Milk', quantity: '1', checked: false },
  { id: '2', name: 'Eggs', quantity: '12', checked: false },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tasks' | 'meals' | 'groceries' | 'assistant'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  // State
  const [tasks, setTasks] = useState<Task[]>([]);
  const [meals, setMeals] = useState<Meal[]>([]);
  const [groceries, setGroceries] = useState<GroceryItem[]>([]);
  const [grocerySuggestions, setGrocerySuggestions] = useState<{ name: string, reason: string }[]>([]);
  const [isGroceryLoading, setIsGroceryLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string>("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [showAddMeal, setShowAddMeal] = useState(false);

  // Load initial data
  useEffect(() => {
    const savedTasks = localStorage.getItem('life-load-tasks');
    const savedMeals = localStorage.getItem('life-load-meals');
    const savedGroceries = localStorage.getItem('life-load-groceries');
    
    setTasks(savedTasks ? JSON.parse(savedTasks) : INITIAL_TASKS);
    setMeals(savedMeals ? JSON.parse(savedMeals) : INITIAL_MEALS);
    setGroceries(savedGroceries ? JSON.parse(savedGroceries) : INITIAL_GROCERIES);
  }, []);

  // Save data
  useEffect(() => {
    if (tasks.length > 0) localStorage.setItem('life-load-tasks', JSON.stringify(tasks));
    if (meals.length > 0) localStorage.setItem('life-load-meals', JSON.stringify(meals));
    if (groceries.length > 0) localStorage.setItem('life-load-groceries', JSON.stringify(groceries));
  }, [tasks, meals, groceries]);

  const addTask = (title: string, category: 'work' | 'personal') => {
    if (!title.trim()) return;
    const newTask: Task = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      priority: 'medium',
      status: 'todo',
      category
    };
    setTasks([newTask, ...tasks]);
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, status: t.status === 'done' ? 'todo' : 'done' } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const addGrocery = (name: string) => {
    if (!name.trim()) return;
    const newItem: GroceryItem = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      quantity: '1',
      checked: false
    };
    setGroceries([newItem, ...groceries]);
  };

  const toggleGrocery = (id: string) => {
    setGroceries(groceries.map(g => g.id === id ? { ...g, checked: !g.checked } : g));
  };

  const deleteGrocery = (id: string) => {
    setGroceries(groceries.filter(g => g.id !== id));
  };

  const addMeal = (name: string, day: string, type: any) => {
    const newMeal: Meal = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      day,
      type,
      ingredients: []
    };
    setMeals([...meals, newMeal]);
    setShowAddMeal(false);
  };

  const askAi = async (prompt: string) => {
    if (!prompt.trim()) return;
    setIsAiLoading(true);
    try {
      const response = await generatePlan(tasks, meals, groceries, prompt);
      setAiResponse(response || "No response from AI.");
    } catch (error) {
      console.error(error);
      setAiResponse("Error connecting to AI.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const getGrocerySuggestions = async () => {
    setIsGroceryLoading(true);
    try {
      const result = await suggestGroceries(meals, groceries);
      setGrocerySuggestions(result.suggestions || []);
    } catch (error) {
      console.error(error);
    } finally {
      setIsGroceryLoading(false);
    }
  };

  const SidebarItem = ({ id, icon: Icon, label }: { id: typeof activeTab, icon: any, label: string }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={cn(
        "flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all duration-200",
        activeTab === id 
          ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
          : "text-slate-500 hover:bg-slate-100 hover:text-slate-900"
      )}
    >
      <Icon size={20} />
      <span className={cn("font-medium", !isSidebarOpen && "hidden")}>{label}</span>
    </button>
  );

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 260 : 80 }}
        className="bg-white border-r border-slate-200 flex flex-col p-4 relative"
      >
        <div className="flex items-center gap-3 mb-8 px-2">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
            <Sparkles size={24} />
          </div>
          {isSidebarOpen && <h1 className="font-bold text-xl tracking-tight">LifeLoad</h1>}
        </div>

        <nav className="flex-1 flex flex-col gap-2">
          <SidebarItem id="dashboard" icon={LayoutDashboard} label="Dashboard" />
          <SidebarItem id="tasks" icon={CheckSquare} label="Tasks" />
          <SidebarItem id="meals" icon={Utensils} label="Meal Plan" />
          <SidebarItem id="groceries" icon={ShoppingCart} label="Groceries" />
          <SidebarItem id="assistant" icon={MessageSquare} label="AI Assistant" />
        </nav>

        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="absolute -right-3 top-20 bg-white border border-slate-200 rounded-full p-1 text-slate-400 hover:text-slate-600 shadow-sm"
        >
          {isSidebarOpen ? <X size={14} /> : <Menu size={14} />}
        </button>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8">
        <header className="mb-8 flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 capitalize">{activeTab}</h2>
            <p className="text-slate-500 mt-1">Manage your daily load with ease.</p>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setActiveTab('assistant')}
              className="flex items-center gap-2 bg-indigo-50 text-indigo-600 px-4 py-2 rounded-full font-medium hover:bg-indigo-100 transition-colors"
            >
              <Sparkles size={18} />
              <span>Ask AI</span>
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
                    <CheckSquare size={24} />
                  </div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tasks</span>
                </div>
                <h3 className="text-4xl font-bold mb-1">{tasks.filter(t => t.status !== 'done').length}</h3>
                <p className="text-slate-500">Pending tasks for today</p>
              </div>

              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                    <Utensils size={24} />
                  </div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Meals</span>
                </div>
                <h3 className="text-4xl font-bold mb-1">{meals.length}</h3>
                <p className="text-slate-500">Meals planned this week</p>
              </div>

              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
                    <ShoppingCart size={24} />
                  </div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Groceries</span>
                </div>
                <h3 className="text-4xl font-bold mb-1">{groceries.filter(g => !g.checked).length}</h3>
                <p className="text-slate-500">Items to buy</p>
              </div>

              <div className="col-span-full bg-indigo-600 text-white p-8 rounded-[2rem] shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold mb-2">AI Insight</h3>
                  <p className="text-indigo-100 mb-6 max-w-xl">
                    You have {tasks.filter(t => t.priority === 'high').length} high-priority tasks. 
                    Let's optimize your schedule to reduce cognitive fatigue.
                  </p>
                  <button 
                    onClick={() => setActiveTab('assistant')}
                    className="bg-white text-indigo-600 px-6 py-3 rounded-2xl font-bold hover:bg-indigo-50 transition-colors"
                  >
                    Get Suggestion
                  </button>
                </div>
                <Sparkles className="absolute right-[-20px] bottom-[-20px] text-white/10 w-64 h-64" />
              </div>
            </motion.div>
          )}

          {activeTab === 'tasks' && (
            <motion.div 
              key="tasks"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-4xl mx-auto"
            >
              <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-bottom border-slate-100 bg-slate-50/50 flex flex-col gap-4">
                  <div className="flex gap-4">
                    <input 
                      type="text" 
                      id="task-input"
                      placeholder="Add a new task..." 
                      className="flex-1 bg-white border border-slate-200 rounded-2xl px-6 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          const category = (document.getElementById('category-select') as HTMLSelectElement).value as 'work' | 'personal';
                          addTask(e.currentTarget.value, category);
                          e.currentTarget.value = '';
                        }
                      }}
                    />
                    <select 
                      id="category-select"
                      className="bg-white border border-slate-200 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="work">Work</option>
                      <option value="personal">Personal</option>
                    </select>
                    <button 
                      onClick={() => {
                        const input = document.getElementById('task-input') as HTMLInputElement;
                        const category = (document.getElementById('category-select') as HTMLSelectElement).value as 'work' | 'personal';
                        addTask(input.value, category);
                        input.value = '';
                      }}
                      className="bg-indigo-600 text-white p-4 rounded-2xl hover:bg-indigo-700 transition-colors"
                    >
                      <Plus size={24} />
                    </button>
                  </div>
                </div>
                <div className="divide-y divide-slate-100">
                  {tasks.map(task => (
                    <div key={task.id} className="p-6 flex items-center justify-between group hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-4">
                        <button 
                          onClick={() => toggleTask(task.id)}
                          className={cn(
                            "transition-colors",
                            task.status === 'done' ? "text-emerald-500" : "text-slate-300 hover:text-slate-400"
                          )}
                        >
                          {task.status === 'done' ? <CheckCircle2 size={24} /> : <Circle size={24} />}
                        </button>
                        <div>
                          <h4 className={cn("font-medium", task.status === 'done' && "line-through text-slate-400")}>
                            {task.title}
                          </h4>
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{task.category}</span>
                        </div>
                      </div>
                      <button 
                        onClick={() => deleteTask(task.id)}
                        className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  ))}
                  {tasks.length === 0 && (
                    <div className="p-12 text-center text-slate-400">
                      <CheckSquare size={48} className="mx-auto mb-4 opacity-20" />
                      <p>No tasks yet. Add one above!</p>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'groceries' && (
            <motion.div 
              key="groceries"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-2xl mx-auto space-y-6"
            >
              <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 bg-amber-50/50 flex gap-4">
                  <input 
                    type="text" 
                    id="grocery-input"
                    placeholder="Add grocery item..." 
                    className="flex-1 bg-white border border-slate-200 rounded-2xl px-6 py-3 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        addGrocery(e.currentTarget.value);
                        e.currentTarget.value = '';
                      }
                    }}
                  />
                  <button 
                    onClick={() => {
                      const input = document.getElementById('grocery-input') as HTMLInputElement;
                      addGrocery(input.value);
                      input.value = '';
                    }}
                    className="bg-amber-600 text-white p-4 rounded-2xl hover:bg-amber-700 transition-colors"
                  >
                    <Plus size={24} />
                  </button>
                </div>
                <div className="divide-y divide-slate-100">
                  {groceries.map(item => (
                    <div key={item.id} className="p-6 flex items-center justify-between group hover:bg-amber-50/30 transition-colors">
                      <div className="flex items-center gap-4">
                        <button 
                          onClick={() => toggleGrocery(item.id)}
                          className={cn(
                            "transition-colors",
                            item.checked ? "text-amber-500" : "text-slate-300 hover:text-slate-400"
                          )}
                        >
                          {item.checked ? <CheckCircle2 size={24} /> : <Circle size={24} />}
                        </button>
                        <span className={cn("font-medium", item.checked && "line-through text-slate-400")}>
                          {item.name}
                        </span>
                      </div>
                      <button 
                        onClick={() => deleteGrocery(item.id)}
                        className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  ))}
                  {groceries.length === 0 && (
                    <div className="p-12 text-center text-slate-400">
                      <ShoppingCart size={48} className="mx-auto mb-4 opacity-20" />
                      <p>Your grocery list is empty.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* AI Suggestions Section */}
              <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-6">
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-2">
                    <Sparkles className="text-amber-500" size={20} />
                    <h3 className="font-bold text-lg">AI Suggestions</h3>
                  </div>
                  <button 
                    onClick={getGrocerySuggestions}
                    disabled={isGroceryLoading}
                    className="text-sm font-bold text-indigo-600 hover:text-indigo-700 disabled:opacity-50"
                  >
                    {isGroceryLoading ? 'Thinking...' : 'Refresh Suggestions'}
                  </button>
                </div>

                {grocerySuggestions.length > 0 ? (
                  <div className="grid grid-cols-1 gap-3">
                    {grocerySuggestions.map((suggestion, idx) => (
                      <div 
                        key={idx} 
                        className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 group"
                      >
                        <div>
                          <p className="font-bold text-slate-800">{suggestion.name}</p>
                          <p className="text-xs text-slate-500">{suggestion.reason}</p>
                        </div>
                        <button 
                          onClick={() => {
                            addGrocery(suggestion.name);
                            setGrocerySuggestions(prev => prev.filter((_, i) => i !== idx));
                          }}
                          className="p-2 bg-white text-indigo-600 rounded-xl shadow-sm hover:bg-indigo-600 hover:text-white transition-all"
                        >
                          <Plus size={18} />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 border-2 border-dashed border-slate-100 rounded-2xl">
                    <p className="text-slate-400 text-sm mb-4">Get smart suggestions based on your meal plan.</p>
                    <button 
                      onClick={getGrocerySuggestions}
                      disabled={isGroceryLoading}
                      className="bg-indigo-50 text-indigo-600 px-6 py-2 rounded-xl font-bold hover:bg-indigo-100 transition-colors"
                    >
                      {isGroceryLoading ? 'Thinking...' : 'Analyze Meal Plan'}
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'assistant' && (
            <motion.div 
              key="assistant"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-3xl mx-auto h-[600px] flex flex-col bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden"
            >
              <div className="p-8 bg-indigo-600 text-white flex items-center gap-4">
                <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                  <Sparkles size={28} />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Life-Load Assistant</h3>
                  <p className="text-indigo-100 text-sm">Always here to help you balance life.</p>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-6">
                {aiResponse ? (
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Sparkles size={16} />
                    </div>
                    <div className="bg-slate-50 p-6 rounded-2xl rounded-tl-none text-slate-700 leading-relaxed shadow-sm markdown-body">
                      <Markdown>{aiResponse}</Markdown>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-slate-400">
                    <MessageSquare size={48} className="mx-auto mb-4 opacity-20" />
                    <p>Ask me anything about your tasks, meals, or groceries.</p>
                  </div>
                )}
                {isAiLoading && (
                  <div className="flex gap-4 animate-pulse">
                    <div className="w-8 h-8 bg-slate-100 rounded-lg"></div>
                    <div className="bg-slate-50 h-20 w-3/4 rounded-2xl rounded-tl-none"></div>
                  </div>
                )}
              </div>

              <div className="p-8 border-t border-slate-100">
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Type your request here..." 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-8 py-4 pr-16 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        askAi(e.currentTarget.value);
                        e.currentTarget.value = '';
                      }
                    }}
                  />
                  <button className="absolute right-4 top-1/2 -translate-y-1/2 text-indigo-600 hover:text-indigo-700 p-2">
                    <ChevronRight size={24} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'meals' && (
            <motion.div 
              key="meals"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              <button 
                onClick={() => setShowAddMeal(true)}
                className="h-64 border-2 border-dashed border-slate-200 rounded-[2rem] flex flex-col items-center justify-center text-slate-400 hover:border-indigo-300 hover:text-indigo-500 transition-all group"
              >
                <div className="p-4 bg-slate-50 rounded-2xl group-hover:bg-indigo-50 transition-colors mb-4">
                  <Plus size={32} />
                </div>
                <span className="font-bold">Add New Meal</span>
              </button>

              {meals.map(meal => (
                <div key={meal.id} className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
                  <div className="flex justify-between items-start mb-4">
                    <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold uppercase tracking-wider">
                      {meal.type}
                    </span>
                    <span className="text-slate-400 font-medium">{meal.day}</span>
                  </div>
                  <h4 className="text-xl font-bold mb-4">{meal.name}</h4>
                  <div className="space-y-2">
                    {meal.ingredients.map((ing, i) => (
                      <div key={i} className="flex items-center gap-2 text-slate-500 text-sm">
                        <div className="w-1.5 h-1.5 bg-slate-300 rounded-full" />
                        {ing}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Add Meal Modal */}
        <AnimatePresence>
          {showAddMeal && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl"
              >
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold">Add New Meal</h3>
                  <button onClick={() => setShowAddMeal(false)} className="text-slate-400 hover:text-slate-600">
                    <X size={24} />
                  </button>
                </div>
                <form onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  addMeal(
                    formData.get('name') as string,
                    formData.get('day') as string,
                    formData.get('type') as any
                  );
                }} className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">Meal Name</label>
                    <input name="name" required type="text" className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">Day</label>
                      <select name="day" className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(d => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">Type</label>
                      <select name="type" className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        {['breakfast', 'lunch', 'dinner', 'snack'].map(t => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <button type="submit" className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-colors mt-4">
                    Save Meal
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
