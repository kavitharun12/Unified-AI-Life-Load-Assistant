export interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate?: string;
  priority: 'low' | 'medium' | 'high';
  status: 'todo' | 'in-progress' | 'done';
  category: 'work' | 'personal';
}

export interface Meal {
  id: string;
  name: string;
  day: string; // e.g., 'Monday'
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  ingredients: string[];
}

export interface GroceryItem {
  id: string;
  name: string;
  quantity: string;
  checked: boolean;
  category?: string;
}

export interface AppState {
  tasks: Task[];
  meals: Meal[];
  groceries: GroceryItem[];
}
